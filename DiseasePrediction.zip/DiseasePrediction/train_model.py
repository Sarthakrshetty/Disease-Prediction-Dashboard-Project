import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.utils import resample
import pickle

# Load dataset
df = pd.read_csv("diabetes.csv")

# Handle imbalance by upsampling minority class
df_majority = df[df.Outcome == 0]
df_minority = df[df.Outcome == 1]

df_minority_upsampled = resample(df_minority,
                                 replace=True,
                                 n_samples=len(df_majority),
                                 random_state=42)

df_balanced = pd.concat([df_majority, df_minority_upsampled])

# Features and target
X = df_balanced.drop("Outcome", axis=1)
y = df_balanced["Outcome"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Accuracy
accuracy = model.score(X_test, y_test)
print("Model Accuracy:", accuracy)

# Save model
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

# Save column order (important for Flask input)
with open("columns.pkl", "wb") as f:
    pickle.dump(list(X.columns), f)
