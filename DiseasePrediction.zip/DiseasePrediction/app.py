from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load your trained ML model (make sure you saved it as model.pkl)
model = pickle.load(open("model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Collect form values
        age = int(request.form["age"])
        sex = int(request.form["sex"])
        bp = int(request.form["bp"])
        cholesterol = int(request.form["cholesterol"])
        smoking = int(request.form["smoking"])
        exercise = int(request.form["exercise"])
        weight = float(request.form["weight"])
        diabetes = int(request.form["diabetes"])

        # Convert into numpy array
        features = np.array([[age, sex, bp, cholesterol, smoking, exercise, weight, diabetes]])

        # Prediction
        prediction = model.predict(features)[0]
        probability = model.predict_proba(features)[0][1] * 100  # % chance of disease

        # Result Text
        if prediction == 1:
            prediction_text = "⚠️ Disease Present"
        else:
            prediction_text = "✅ No Disease Detected"

        probability_text = f"Model Confidence: {probability:.2f}%"

        return render_template(
            "index.html",
            prediction_text=prediction_text,
            probability_text=probability_text,
            probability=probability
        )

    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)
